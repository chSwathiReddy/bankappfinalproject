package com.bankapp;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bankapp.entities.Account;
import com.bankapp.entities.TransactionLog;
import com.bankapp.service.AccountService;

@SpringBootApplication
public class BankapplicationApplication implements CommandLineRunner{

	@Autowired
	private AccountService accountService;
	

	
	public static void main(String[] args) {
		SpringApplication.run(BankapplicationApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		
		/*
		 * Account account1=new Account("swathi", 67889912, "swathi@gmailcom",
		 * "hyderabad","Axis", 5000,"SAVINGS");
		 * 
		 * Account account2=new Account("suppi", 6786781, "suppi@vgmailcom",
		 * "hyderabad","ICICI", 7000,"CURRENT");
		 * 
		 * Account account3=new Account("Shalini", 671234567, "shalini@3gmailcom",
		 * "secundrabad","SBI", 4000, "SAVINGS");
		 * 
		 * Account account4=new Account("preethi", 675612489, "preethi@gmailcom",
		 * "secundrabad","Syndicate", 8000,"SAVINGS");
		 * 
		 * Account account5=new Account("srujana", 671234567, "sruj@3gmailcom",
		 * "chennai","Andhra", 5670, "CURRENT");
		 * 
		 * 
		 * accountService.addCustomerAccount(account1);
		 * accountService.addCustomerAccount(account2);
		 * accountService.addCustomerAccount(account3);
		 * accountService.addCustomerAccount(account4);
		 * accountService.addCustomerAccount(account5);
		 */
		
		
	}

}
