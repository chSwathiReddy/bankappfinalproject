

export class AccountDetails {
    accountId:number;
  acoountHolderName:String 
	 mobileNum:number;
	 email:String;
	address:String;
	bankName:String;
	amount:number;
	accountType:String;
}
