import { Withdraw } from './withdraw';

describe('Withdraw', () => {
  it('should create an instance', () => {
    expect(new Withdraw()).toBeTruthy();
  });
});
