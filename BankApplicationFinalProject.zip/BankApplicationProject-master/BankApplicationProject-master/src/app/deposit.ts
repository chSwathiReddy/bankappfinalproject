export class Deposit {
    depositaccountId: number;
    amountToDeposit: number;
}
