export class Withdraw {
    withdrawAccountId:number;
    amountToWithdraw: number;
}
