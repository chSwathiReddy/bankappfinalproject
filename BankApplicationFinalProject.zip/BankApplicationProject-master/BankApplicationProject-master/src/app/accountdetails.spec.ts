import { AccountDetails } from './accountdetails';

describe('Account', () => {
  it('should create an instance', () => {
    expect(new AccountDetails()).toBeTruthy();
  });
});
