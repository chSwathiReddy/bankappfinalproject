
export class Transfer {
    fromAccountId: number;
    toAccountId: number;
    amount: number;
}
